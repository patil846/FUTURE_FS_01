export const projects = [
  {
    id: 1,
    title: "E-Commerce Mini",
    description: "A responsive storefront with cart, search, and checkout UI. Built with React and Context API.",
    tags: ["React", "Context API", "LocalStorage"],
    demo: "https://myecommerce-demo.com",
    source: "https://github.com/username/ecommerce-mini"
  },
  {
    id: 2,
    title: "Dev Blog",
    description: "Markdown-powered blog with client-side search, code syntax highlighting, and mobile-friendly design.",
    tags: ["React", "Marked", "Highlight.js"],
    demo: "https://mydevblog.com",
    source: "https://github.com/username/dev-blog"
  },
  {
    id: 3,
    title: "Portfolio Starter",
    description: "Accessible component library and starter portfolio template for developers.",
    tags: ["React", "A11y", "CSS"],
    demo: "https://portfolio-starter.com",
    source: "https://github.com/username/portfolio-starter"
  },
  {
    id: 4,
    title: "Task Manager",
    description: "Full-stack task management app with authentication, drag-and-drop tasks, and reminders.",
    tags: ["MERN", "JWT", "TailwindCSS"],
    demo: "https://taskmanager-app.com",
    source: "https://github.com/username/task-manager"
  },
  {
    id: 5,
    title: "Weather Dashboard",
    description: "Real-time weather dashboard fetching live API data with location search and unit toggle.",
    tags: ["React", "OpenWeather API", "Chart.js"],
    demo: "https://weatherdash-demo.com",
    source: "https://github.com/username/weather-dashboard"
  }
];
