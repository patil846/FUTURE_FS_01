import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Projects from './components/Projects'
import Resume from './components/Resume'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App(){
  return (
    <>
      <Helmet>
        <title>Pragati | Wev Developer Portfolio</title>
        <meta name="description" content="Interactive resume, projects, and contact form."/>
      </Helmet>
      <Navbar />
      <Routes>
        <Route path="/" element={<>
          <Hero />
          <About />
          <Projects />
          <Contact />
        </>} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/resume" element={<Resume />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
      <Footer />
    </>
  )
}
