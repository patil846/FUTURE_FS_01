import React from 'react'

export default function About(){
  return (
    <section className="container grid" style={{marginTop:24}}>
      <div className="card">
        <h2>About Me</h2>
        <p className="muted">I’m a Web developer focused on converting ideas into engaging web experiences. I care about performance, accessibility, and clean code.</p>
      </div>
      <div className="grid skills">
        {[
          'React','JavaScript','TypeScript','HTML','CSS','Node.js'
        ].map(s => (
          <div className="card" key={s}><strong>{s}</strong><p className="muted">Intermediate–Advanced</p></div>
        ))}
      </div>
    </section>
  )
}
