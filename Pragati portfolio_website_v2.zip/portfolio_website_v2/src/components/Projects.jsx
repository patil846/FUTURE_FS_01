import { projects } from "../data/projects";

export default function Projects() {
  return (
    <section className="container">
      <h2>Featured Projects</h2>
      <div className="grid projects">
        {projects.map((p) => (
          <div key={p.id} className="project-card">
            <h3>{p.title}</h3>
            <p>{p.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
