import React from 'react'
import { Link } from 'react-router-dom'

export default function Hero(){
  return (
    <section className="container hero">
      <div className="hero-card">
        <p className="muted"> </p>
        <h1 style={{fontSize:'48px',margin:'6px 0 10px'}}>I Am <span style={{color:'var(--accent)'}}>Pragati</span></h1>
        <h3 className="muted" style={{marginTop:0}}>Web Developer</h3>
        <p className="muted">I build fast, accessible, responsive web apps with React. Explore my work and discover the power of delightful UX.</p>
        <div style={{display:'flex', gap:'12px', marginTop:'16px'}}>
          <a href="#contact" className="btn">Hire Me</a>
          <Link to="/projects" className="btn ghost">Learn More</Link>
        </div>
      </div>
      {/* Updated image */}
      <img 
        src="/myphoto.png" 
        alt="My Portrait" 
        style={{
          width:'100%',
          borderRadius:'24px',
          border:'1px solid rgba(255,255,255,.07)'
        }}
      />
    </section>
  )
}
