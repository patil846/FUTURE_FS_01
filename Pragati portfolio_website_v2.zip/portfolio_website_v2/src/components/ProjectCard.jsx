import React from "react";

export default function ProjectCard({ p }) {
  return (
    <div className="project-card">
      {/* Render image only if available */}
      {p.image && <img src={p.image} alt={p.title} />}

      <h3>{p.title}</h3>
      <p>{p.description}</p>

      {/* Render tags safely */}
      {p.tags && (
        <div className="tags">
          {p.tags.map((tag, i) => (
            <span key={i}>{tag}</span>
          ))}
        </div>
      )}

      {/* Optional links */}
      <div className="buttons">
        {p.demo && <a href={p.demo}>Live Demo</a>}
        {p.source && <a href={p.source}>Source</a>}
      </div>
    </div>
  );
}
