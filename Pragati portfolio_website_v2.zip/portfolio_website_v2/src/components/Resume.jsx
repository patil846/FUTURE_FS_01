import React from 'react'

export default function Resume(){
  return (
    <section className="container grid">
      <div className="card">
        <h2>Experience</h2>
        <ul>
          <li><strong>React Developer</strong> — Freelance (2023–Present)</li>
          <li><strong>Frontend Intern</strong> — Web Studio (2022–2023)</li>
        </ul>
      </div>
      <div className="card">
        <h2>Education</h2>
        <ul>
          <li>B.Tech in Computer Science — 2022</li>
        </ul>
      </div>
      <div className="card">
        <h2>Certifications & Achievements</h2>
        <ul>
          <li>JavaScript Algorithms & Data Structures</li>
          <li>Top 5% on a Coding Challenge</li>
        </ul>
      </div>
    </section>
  )
}
