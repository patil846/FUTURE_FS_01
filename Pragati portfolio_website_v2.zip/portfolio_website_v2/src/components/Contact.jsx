import React, { useRef, useState } from 'react'
import emailjs from 'emailjs-com'

export default function Contact(){
  const formRef = useRef()
  const [status, setStatus] = useState(null)

  const onSubmit = async (e) => {
    e.preventDefault()
    setStatus('sending')
    try {
      // Replace these with your EmailJS IDs
      const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || ''
      const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || ''
      const PUBLIC_KEY  = import.meta.env.VITE_EMAILJS_PUBLIC_KEY  || ''
      if(!SERVICE_ID || !TEMPLATE_ID || !PUBLIC_KEY){
        setStatus('Please configure EmailJS env variables in a .env file.')
        return
      }
      await emailjs.sendForm(SERVICE_ID, TEMPLATE_ID, formRef.current, PUBLIC_KEY)
      setStatus('Sent! I will get back to you soon.')
      formRef.current.reset()
    } catch (err){
      console.error(err)
      setStatus('Failed to send. Please try again later.')
    }
  }

  return (
    <section id="contact" className="container grid" style={{gridTemplateColumns:'1fr 1fr'}}>
      <div className="card">
        <h2>Contact</h2>
        <p className="muted">Have a project in mind? Send me a message and I’ll reply ASAP.</p>
        <form ref={formRef} onSubmit={onSubmit} className="grid" style={{gap:'12px'}}>
          <input className="card" name="from_name" placeholder="Your name" required />
          <input className="card" type="email" name="reply_to" placeholder="Email address" required />
          <input className="card" name="subject" placeholder="Subject" />
          <textarea className="card" name="message" rows="5" placeholder="Your message" required></textarea>
          <button className="btn" type="submit">Send Message</button>
        </form>
        {status && <p className="muted" style={{marginTop:'10px'}}>{status}</p>}
      </div>
      <div className="card">
        <h3>Get in touch</h3>
        <p className="muted">Email: <a href="pragatipatil020@gmail.com">pragatipatila@example.com</a></p>
        <p className="muted">LinkedIn: <a href="https://in.linkedin.com/in/pragati-rajendra-patil-94325b31a" target="_blank" rel="noreferrer">Pragati Patil</a></p>
      </div>
    </section>
  )
}
