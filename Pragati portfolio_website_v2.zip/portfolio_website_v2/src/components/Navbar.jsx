import React from 'react'
import { Link, NavLink } from 'react-router-dom'

export default function Navbar(){
  return (
    <header>
      <div className="container">
        <nav>
          <Link to="/" className="brand"><img src="/logo.svg" alt="logo" /><span>RPX</span></Link>
          <div className="nav-links">
            <NavLink to="/" end>Home</NavLink>
            <NavLink to="/projects">Projects</NavLink>
            <NavLink to="/resume">Resume</NavLink>
            <NavLink to="/contact">Contact</NavLink>
            <a className="btn" href="#contact">Hire Me</a>
          </div>
        </nav>
      </div>
    </header>
  )
}
