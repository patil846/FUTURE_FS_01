import React from 'react'

export default function Footer(){
  return <footer>© {new Date().getFullYear()} Pragati. Built with React & Vite.</footer>
}
