# React Portfolio (Frontend Only)

A modern React portfolio inspired by the ReactProx layout. Built with Vite.

## Features
- Interactive resume & portfolio
- Contact form using EmailJS (client-only)
- SEO (meta tags, Open Graph, robots.txt, sitemap.xml)
- Accessible, responsive design

## Setup
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## EmailJS (Contact Form)
1. Create a free account at https://www.emailjs.com/
2. Create a service and a template.
3. Add a `.env` file at the project root with:
   ```
   VITE_EMAILJS_SERVICE_ID=your_service_id
   VITE_EMAILJS_TEMPLATE_ID=your_template_id
   VITE_EMAILJS_PUBLIC_KEY=your_public_key
   ```
4. Restart `npm run dev`.

## Customization
- Replace `/public/hero.svg` with your photo (same filename) or update the path in `Hero.jsx`.
- Update `src/data/projects.js` with your real projects.
- Replace "Nikita" and links in `Contact.jsx` and `Navbar.jsx`.

## Deploy
- Vercel / Netlify: import the repo, use `npm run build`. Set the above `VITE_...` env vars for EmailJS.
